(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1mojsay._.js","static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1lxvjq5._.js","static/chunks/09d6_next_dist_compiled_next-devtools_index_02q9acx.js","static/chunks/09d6_next_dist_compiled_react-dom_1ivcjv1._.js","static/chunks/09d6_next_dist_compiled_react-server-dom-turbopack_0ahwmqw._.js","static/chunks/09d6_next_dist_compiled_0lcbdqr._.js","static/chunks/09d6_next_dist_client_0yvidh3._.js","static/chunks/09d6_next_dist_1dy_t_k._.js","static/chunks/09d6_@swc_helpers_cjs_0mt5vnp._.js"],
    source: "entry"
});
