(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/09d6_202314a._.js","static/chunks/web-app_src_providers_Providers_tsx_192ns-n._.js","static/chunks/web-app_src_app_globals_0xxt_d4.css","static/chunks/web-app_src_0aymyw1._.js","static/chunks/09d6_next_dist_0wp3-bp._.js","static/chunks/web-app_src_app_global-error_tsx_19o93j2._.js","static/chunks/web-app_043-_c7._.js"],
    source: "entry"
});
